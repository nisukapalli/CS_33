/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_422(unsigned x)
{
    return x + 3281147992U;
}

unsigned addval_127(unsigned x)
{
    return x + 3347671068U;
}

unsigned getval_301()
{
    return 3347663086U;
}

unsigned addval_262(unsigned x)
{
    return x + 2425393240U;
}

void setval_286(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_354(unsigned x)
{
    return x + 3251079496U;
}

unsigned getval_352()
{
    return 3281012897U;
}

unsigned getval_183()
{
    return 1103335512U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_264(unsigned *p)
{
    *p = 3674786441U;
}

void setval_417(unsigned *p)
{
    *p = 2429192347U;
}

unsigned getval_307()
{
    return 2430634313U;
}

unsigned addval_237(unsigned x)
{
    return x + 3375945353U;
}

unsigned addval_140(unsigned x)
{
    return x + 3264272009U;
}

unsigned getval_336()
{
    return 3678983817U;
}

void setval_174(unsigned *p)
{
    *p = 3687104905U;
}

void setval_245(unsigned *p)
{
    *p = 3685007753U;
}

unsigned addval_109(unsigned x)
{
    return x + 3767093553U;
}

void setval_295(unsigned *p)
{
    *p = 3523794601U;
}

void setval_236(unsigned *p)
{
    *p = 3767093441U;
}

unsigned getval_122()
{
    return 2429979061U;
}

unsigned addval_454(unsigned x)
{
    return x + 3281043841U;
}

void setval_489(unsigned *p)
{
    *p = 3223896457U;
}

unsigned getval_159()
{
    return 2497743176U;
}

void setval_278(unsigned *p)
{
    *p = 2425408169U;
}

unsigned addval_378(unsigned x)
{
    return x + 2425408139U;
}

unsigned getval_463()
{
    return 3674784137U;
}

unsigned getval_371()
{
    return 3525362057U;
}

unsigned addval_261(unsigned x)
{
    return x + 3286272328U;
}

void setval_105(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_435()
{
    return 3674789515U;
}

unsigned getval_172()
{
    return 3531129225U;
}

void setval_212(unsigned *p)
{
    *p = 3675838089U;
}

void setval_437(unsigned *p)
{
    *p = 3224947337U;
}

unsigned getval_413()
{
    return 3221804553U;
}

unsigned addval_244(unsigned x)
{
    return x + 3267463427U;
}

unsigned getval_479()
{
    return 3767224569U;
}

void setval_165(unsigned *p)
{
    *p = 3284834643U;
}

unsigned getval_274()
{
    return 3771287602U;
}

unsigned getval_223()
{
    return 3526937241U;
}

unsigned addval_308(unsigned x)
{
    return x + 3523267209U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
